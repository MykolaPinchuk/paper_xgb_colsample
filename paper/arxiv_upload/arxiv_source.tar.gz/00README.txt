This arXiv source bundle contains:
- main.tex (paper source)
- assets/ (figures)
- tables/ (generated table inputs)

To compile locally (PDFLaTeX):
  pdflatex main.tex
  pdflatex main.tex
